
rtl_433_ESP(6): RAW (152693): +63-163+206-291+1601-1577+1594-1567+1599-1586+1592-1394+209-536+179-548+179-545+203-548+176-535+210-541+175-542+206-532+210-536+178-551+168-562+178-612+206-880+207-594+210-893+197-539+190-611+169-983+207-960+183-962+200-976+180-895+203-532+205-599+175-907+210-538+176-563+178-548+180-552+204-521+207-537+173-566+178-613+182-906+202-601+176-922+170-557+183-543+201-548+173-609+196-288+202-284+1593-1595+1575-1586+1612-1564+1607-1384+201-519+205-544+205-532+197-540+183-544+180-551+206-523+203-536+197-541+180-546+179-553+205-574+202-898+198-590+200-911+207-517+205-597+201-969+198-962+172-986+204-961+182-893+206-532+209-586+209-898+196-536+205-517+203-549+181-529+208-539+199-512+207-537+207-600+175-921+197-584+200-904+208-537+171-533+219-539 
rtl_433_ESP(7): demod(5) - Skylink HA-434TL motion sensor - 5636
rtl_433_ESP(7): demod(5) - Prologue, FreeTec NC-7104, NC-7159-675 temperature sensor - 5636
N: Subject: /RTL_433toMQTT
N: Received json : {"model":"Acurite-986","id":20542,"channel":"2F","battery":"OK","temperature_C":-17.7778,"status":0,"mic":"CRC","protocol":"Acurite 986 Refrigerator / Freezer Thermometer","rssi":-65,"duration":152693}
N: Subject: /RTL_433toMQTT
N: Received json : {"model":"Acurite-986","id":20542,"channel":"2F","battery":"OK","temperature_C":-17.7778,"status":0,"mic":"CRC","protocol":"Acurite 986 Refrigerator / Freezer Thermometer","rssi":-65,"duration":152693}
rtl_433_ESP(7): demod(5) - Acurite 986 Refrigerator / Freezer Thermometer - 5636
rtl_433_ESP(7): demod(6) - Philips outdoor temperature sensor (type AJ3650) - 5636